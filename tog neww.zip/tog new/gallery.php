<?php require_once ('include/head.php') ?>
<title>Our Gallery</title>
</head>

<body>
    <?php require_once ('include/navbar.php') ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">

        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/411002921_744724281021069_6087211645684134570_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeGtCoyqHZ0AWJ6R3nNUouAJuVXBefbcS8-5VcF59txLz192qVZk_V4qyhl9clgELGbfsy-BSdLJqQCAxTCuSYDY&_nc_ohc=rUQridxFUCkQ7kNvgEVtnbd&_nc_ht=scontent-mba1-1.xx&oh=00_AfAMeQ1QLXL0u08HM3TBd1E8PkTu2eVIc_Yh8990qC3qNw&oe=66355F60"
            alt="" class="max-w-full">
        <img src="../frontend/images/2016.jpg" alt="" class="max-w-full">
        <img src="../frontend/images/2018a.jpg" alt="" class="max-w-full">
        <img src="../frontend/images/2023.jpg" alt="" class="max-w-full">
        <img src="../frontend/images/2019.jpg" alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/275112756_2856888241279689_4531416309850648255_n.jpg?stp=dst-jpg_p180x540&_nc_cat=111&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeFeXMmlcjhK6wJIiIRutwWd4v_XT-2-NDXi_9dP7b40NfrFbuZ1FW0QndC97XpNgGKKjeASpF08-qi1U676PD7r&_nc_ohc=-GXzWu6pS_4Ab78Dxp7&_nc_oc=AdhyUHu0RYjcZS-M8o63v-tZ9qqVUdr2XlJiaGIW_9drqIfojNbaeRWBR79UW19XNfM&_nc_ht=scontent-mba1-1.xx&oh=00_AfD_c8gVJeW_YpxkOUvoDnDdjQPoLO5mha02cc1QrUJ9eA&oe=6635513D"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/274516710_2850206795281167_4886646808871676826_n.jpg?stp=dst-jpg_p600x600&_nc_cat=106&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHWtinFnW7tHHoyrgkgVv0Jay1g79LiOglrLWDv0uI6HBGe1vVQA3ixpkwySSsg2SMXMIIm51P10QU-1SpDc1B&_nc_ohc=p9U5Y4kSNAEQ7kNvgF9tkn_&_nc_ht=scontent-mba1-1.xx&oh=00_AfC2grK9ne2tLoimAYTh7KHrS4mNEXnAZGNeG301PmhDcg&oe=66355432"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/274585996_2850229055278941_1031221946848304757_n.jpg?stp=dst-jpg_p600x600&_nc_cat=108&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeHcTB0LOdvOyLbzqoFCn745nmGBC03em4ieYYELTd6biL2BeHasDGDmOM4Dpkkw9iAW6MJdwTF4DqR5_EljuirT&_nc_ohc=fovMLYpArQsAb7xUyGR&_nc_oc=Adi5DfHED7pW3nwAyYE01E1R6z7v6zzM0wVJFGZbpaT4h26qgzdHwdTFGKIm7xZBEfo&_nc_ht=scontent-mba1-1.xx&oh=00_AfCj83gEAtVZVdsoNzUjr4UamTSQznZiTpaT9mRG6IKJYQ&oe=6635506C"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/434683311_808159214677575_3111886116486786678_n.jpg?stp=dst-jpg_p480x480&_nc_cat=104&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeHqjOQ6bHSwsOzp7duEduWPu9blhnpTzny71uWGelPOfHGzjY9IMKm_cxWVscmmQdjzDUXgB3eeOB7Bdfyv5d8k&_nc_ohc=uoeGTzWQZwMQ7kNvgHpN4UE&_nc_ht=scontent-mba1-1.xx&oh=00_AfA5q4LrftX2P9aCKsQrausrTXjUYUJnYNxg6zMA3Hugng&oe=66354C88"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/274586079_2850212938613886_6890044712433481421_n.jpg?stp=dst-jpg_p600x600&_nc_cat=111&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeGWS_9T9aUmdyV7TMGHr_c6GvTzLYnRWG4a9PMtidFYbvaAqDoC5f5EyjlPxnn-gfqg8bFZP8fWn9RX2ggja7Nk&_nc_ohc=46DKVocsaMYQ7kNvgE9sFbz&_nc_ht=scontent-mba1-1.xx&oh=00_AfCqBiIqe1u9eCe_fmk-qcygSwWDs-p3wmnwOp7ei1LSxA&oe=6635695E"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/370564237_679430450883786_6896157495557295502_n.jpg?stp=dst-jpg_p600x600&_nc_cat=108&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeGp5EpIyCYC6Ed9reDkAoYdecZ_cfr8OSB5xn9x-vw5IBskjkXRbyn_1_lbUADC_EvRXXGeQgt-ZNlhs-KO7Bi-&_nc_ohc=82915qG1wNgAb6S5koW&_nc_ht=scontent-mba1-1.xx&oh=00_AfBOu_hu1TR5TONPKIpdMMPWB3L24zheRnHA1pygGgzj5Q&oe=663560A3"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/318416688_3068197120148799_7984053280739284548_n.jpg?stp=dst-jpg_p600x600&_nc_cat=101&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeHSCv0n5-nop9cKshVA7kTB4mG6O7tGZWbiYbo7u0ZlZpLu8a1AgnGGjUetzfXaxE3FqRJTPPdTtjWAUqR0nvBj&_nc_ohc=6jfkNqTSItQQ7kNvgHjrQOq&_nc_ht=scontent-mba1-1.xx&oh=00_AfAYbkysVx7lU2sWu0VEqThpw9EtbOEKVNYSoZHEuNBeqQ&oe=66355295"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/434719548_808159184677578_2198382548628987500_n.jpg?stp=dst-jpg_p480x480&_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEDmaml6FGYvIQ4yuKrJabLC5l9HB6wdrsLmX0cHrB2u4lJQSBX6mLaGW7Eayt-h9X6DDgBD81fiCiAfJ5LfaXO&_nc_ohc=enlo4c7Y4pcQ7kNvgH3joro&_nc_ht=scontent-mba1-1.xx&oh=00_AfDNgAIgQZgvtuPQdl7Hb64eMyb0ei4tuiq71CIgn3zEZw&oe=66355288"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/340773543_234481822436808_6532482825376586947_n.jpg?stp=dst-jpg_p600x600&_nc_cat=107&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEUqK-znSTPWtazeVISZ7djlXwd-Usj0B-VfB35SyPQH10_xvrUoBlTUrAHswmClTSiPtYQvx1ke9o3I32OkJuq&_nc_ohc=YZqaxBDE5kkAb7wjgA6&_nc_ht=scontent-mba1-1.xx&oh=00_AfCB_jdbUyE5EYfgtSJwDtRRzHp7OUiX37KmQjo2PZ1Igw&oe=66354FC6"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/412711608_744724284354402_693583057613039433_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeHwbm8LF-TDWjcwEURvOFq9vgDSOiX0bqS-ANI6JfRupDYqa4HAyVMd5D140wbrj7qQAZpm5CZTv9ys4pOOrFQW&_nc_ohc=kjaBBENUDd0Q7kNvgG9mQp4&_nc_ht=scontent-mba1-1.xx&oh=00_AfC4nSaSMRPVmimrZ6fZUHXkdmboTbfIPRQi5oK7ER7UhQ&oe=66357C6A"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/411005990_744724277687736_4479583183166740317_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeH3DGtY5dRI5yMnOemGt4Om1Dt-TZ8cArjUO35NnxwCuCc0QIkiK0DSH6oPh5mG1tuPuFk0yz3MJf2k-VPeMURR&_nc_ohc=h3MC9bd7w4UAb7Juvhq&_nc_ht=scontent-mba1-1.xx&oh=00_AfA3IGl6_E8UJ3HCibK6ExlgjdxOKjb0CTs5VP2flNPWWw&oe=66354D03"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/412853846_744724307687733_4506406382179656943_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeHTQvTgRDSe0Dp9JYDTDZVvRS9Hqn455KxFL0eqfjnkrGL88klJWmenWaouzt0E5n4xtEFR66CcFBpszMwRyBpZ&_nc_ohc=tDEAaJxTmW4Ab5j2Ikx&_nc_ht=scontent-mba1-1.xx&oh=00_AfDpCjyRYIQIzmNZgE-RUp2HMicQtNV7ll_45tO98xmzlQ&oe=66354CA2"
            alt="" class="max-w-full">
        <img src="https://scontent-mba1-1.xx.fbcdn.net/v/t39.30808-6/412714297_744724297687734_7514234718444202500_n.jpg?_nc_cat=102&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeF98a58OCP-Cldt8k2atBmeInkTO2hlDBUieRM7aGUMFe_ynXkfjQMKtIf14_US8BFVubFz7-jv9z96rSP2AwKM&_nc_ohc=CCICk9-u5MYQ7kNvgFKfg3r&_nc_ht=scontent-mba1-1.xx&oh=00_AfD8Qxs6iI2u37QBci29S0ywureEQHTLqAUcAggn37i8dw&oe=6635739A"
            alt="" class="max-w-full">
    </div>



    <?php require_once ('include/footer.php') ?>


    <script>
        // const mobileMenuButton = document.getElementsById('mobileMenuButton');
        const mobileMenuButton = document.getElementById('mobileMenuButton');
        // const mobileMenu = document.getElementsById('mobileMenu');
        const mobileMenu = document.getElementById('mobileMenu');

        mobileMenuButton.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    </script>
    <script>




        tailwind.config = {
            theme: {
                keyframes: {
                    blink: {
                        '50%': { opacity: '0' }
                    },
                    scroll: {
                        '0%': { transform: 'translateX(0)' },
                        '100%': { transform: 'translateX(-100%)' },
                    }
                },
                animation: {
                    blin: 'blink 0.8s infinite',
                    scrolll: 'scroll 10s linear infinite',
                },
                extend: {
                    colors: {
                        clifford: '#da373d',
                    }
                }
            }
        }
    </script>
</body>

</html>